# Puzzle-l3-2023-grp6

This project was carried out as part of the software engineering course in our Bachelor's degree in Mathematics and Computer Science applied to the humanities and social sciences. It's a java application that lets you play a sliding puzzle. 
